<template>
  <div id="app">
    <div class="appBox">
      我是父组件
    </div>
    <hello-world v-for="(item, index) in starArr" :key="index" :count="item"/>
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue'

export default {
  name: 'app',
  components: {
    HelloWorld
  },
  data() {
    return {
      str: [],
      starArr: [4, 2, 3, 4, 5]
    }
  },
  methods: {
    acceptMsg(data) {
      this.str = data
    }
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.appBox{
  width: 100%;
  height: 200px;
  background: orange;
}
</style>
