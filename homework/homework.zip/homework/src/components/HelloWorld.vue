<template>
  <div class="hello">
      <p>
        <span :class="{actice: index < num}" v-for="(item, index) in 5" :key="index" @click="Fn(item)">★</span>
      </p>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: ['count'],
  data() {
    return {
      num: 3
    }
  },
  methods: {
    Fn(item) {
      this.num = item
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.box{
  width: 100%;
  height: 200px;
  background: skyblue;
}
.pop{
  width: 300px;
  height: 150px;
  border: 1px solid black;
}
.actice{
  color: goldenrod;
}
</style>
