import Vue from 'vue'
import App from './App.vue'
import LazyLoad from 'vue-lazyload'
import Vant from 'vant'
import 'vant/lib/index.css';

Vue.config.productionTip = false

Vue.use(LazyLoad, {
  loading: 'http://img.mp.sohu.com/upload/20170715/7b3ce9cd49604308bdd2b7755f52cab9_th.png',
  // 图片因为某种加载不出来显示的默认图片
  error: 'http://s10.sinaimg.cn/mw690/006emaUrgy71o5Yrirvb9&690'
})

Vue.use(Vant)

new Vue({
  render: h => h(App),
}).$mount('#app')
